<template>
  <footer class="home-footer">
    <div class="wrapper">
      <div class="copyright">Copyright 2020 All Rights Reserved | 蜀ICP备17028486号</div>
      <div class="contact">全国客户服务热线: 028-88888888 | 成都高新科技有限公司提供技术服务</div>
    </div>
  </footer>
</template>

<script>
export default {};
</script>

<style lang="stylus" scoped>
.home-footer {
  height: 60px;
  line-height: 60px;
  font-size: 14px;
  color: #fff;
  background: $primaryColor;

  .copyright {
    float: right;
  }
}
</style>
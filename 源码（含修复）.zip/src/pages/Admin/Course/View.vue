<template>
  <div class="view-paper">
    <el-card class="paper-info">
      <div class="paper-base-info">
        <ul>
          <li>
            <label for>试卷名称：</label>
            <span>网络安全技术基础国家考试测试(卷1)</span>
          </li>
          <li>
            <label for>试卷描述：</label>
            <span>网络安全技术基础-TCPIP协议介绍-IP地址分类(卷1)网络安全技术基础-TCPIP协议介绍-IP地址分类(卷1)网络安全技术基础-TCPIP协议介绍-IP地址分类(卷1) 网络安全技术基础-TCPIP协议介绍-IP地址分类(卷1)网络安全技术基础-TCPIP协议介绍-IP地址分类(卷1)(卷1)</span>
          </li>
          <li>
            <label for>试卷总分：</label>
            <span>100分</span>
          </li>
          <li>
            <label for>试卷难度：</label>
            <span>难</span>
          </li>
          <li>
            <label for>试卷来源：</label>
            <span>
              <ol>
                <li>
                  <label for>课程名称</label>
                  <span>TCPIP协议介绍</span>
                </li>
                <li>
                  <label for>所属章</label>
                  <span>IP地址分类</span>
                </li>
                <li>
                  <label for>所属节</label>
                  <span>网络安全技术基础一阶段考试</span>
                </li>
              </ol>
            </span>
          </li>
        </ul>
      </div>

      <section>
        <div class="questions">
          <div class="questions-header">
            <h3>
              第一部分 单选题
              <span>（本部分共3道题）</span>
            </h3>
          </div>
          <div class="questions-content">
            <ul>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
              <li>
                <dl>
                  <dt>
                    <h3>
                      1 在生产管理信息系统中，下列操作步骤能正确将工单推进流程的是？
                      <span>(2分)</span>
                    </h3>
                  </dt>
                  <dd>
                    <el-radio label="1">A、在工具栏中点击workflow标签</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">B、在缺陷单界面中点击推进流程按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">C、在缺陷单界面中点击提交按钮</el-radio>
                  </dd>
                  <dd>
                    <el-radio label="1">D、后台启动流程推进</el-radio>
                  </dd>
                </dl>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </el-card>
    <el-card class="overview">
      <h3>试卷概览</h3>
      <ul>
        <li>总分值：100分</li>
        <li>总试题：17题</li>
        <li>共有5部分</li>
        <li>单选4题 20分</li>
        <li>多选4题 20分</li>
        <li>判断4题 20分</li>
        <li>填空4题 20分</li>
        <li>问答1题 20分</li>
      </ul>
      <el-button type="primary">编辑试卷</el-button>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="stylus">
.view-paper {
  display: flex;
  margin-top: 30px;

  .paper-info {
    position: relative;
    flex: 1;
    padding: 25px 20px;

    .paper-base-info {
      li {
        font-size: 14px;
        line-height: 22px;
        margin-bottom: 20px;
        display: flex;

        &>label {
          color: #666;
        }

        &>span {
          flex: 1;
          margin-left: 1em;
          color: #999;

          label {
            width: 5em;
            color: #99A9BF;
          }

          span {
          }
        }
      }
    }

    .questions {
      border: 1px solid #EBEEF5;

      .questions-header {
        background: #F5F7FA;
        line-height: 20px;
        padding: 20px;
        border-bottom: 1px solid #EBEEF5;

        h3 {
          font-size: 16px;
          color: #303030;
        }

        span {
          font-size: 14px;
          color: #999;
        }
      }

      .questions-content {
        padding: 40px;

        li:not(:last-child) { 
          margin-bottom: 50px;
        }

        dl {
          dt {
            margin-bottom: 20px;

            h3 {
              font-size: 16px;
              color: #333;
              font-weight: normal;
            }

            span {
              font-size: 14px;
              color: #999;
            }
          }

          dd {
            line-height: 40px;
            color: #666;
          }
        }
      }
    }
  }

  .overview {
    width: 260px;
    margin-left: 15px;
    margin-right: 90px;
    padding: 15px 10px;
    height: fit-content;

    h3 {
      font-size: 16px;
      color: #333;
      line-height: 22px;
      margin-bottom: 20px;
    }

    li {
      line-height: 30px;
      font-size: 14px;
      color: #666;
    }

    .el-button {
      width: 100%;
      height: 48px;
      line-height: 24px;
      margin-top: 20px;
    }
  }
}
</style>
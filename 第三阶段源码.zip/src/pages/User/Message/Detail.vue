<template>
  <el-card class="message-info">
    <header>
      <h1>【新用户特惠】数据传输DTS新用户专享优惠来袭，首月低至99元！</h1>
      <time>2020-03-16 16:20:20</time>
    </header>
    <section>
      <p>尊敬的用户95120****@qq.com 您好！</p>
      <p>数据传输DTS新用户试用专享优惠来袭！</p>
      <p>同步medium规格实例 / 订阅实例，99元/1个月；试用后续费、升级享99元，限1个月，限1次。</p>
      <p>数据传输服务致力于在公共云、混合云、数据分析建仓场景下，解决远距离、毫秒级异步数据传输难题，轻松构建安全、可扩展、高可用的数据架构</p>
      <p></p>
    </section>

    <footer>
      <el-button>上一条(未读)</el-button>
      <el-button>下一条(未读)</el-button>
    </footer>
  </el-card>
</template>

<script>
export default {};
</script>

<style lang="stylus" >
.message-info {
  padding: 20px 120px;

  header {
    text-align: center;
    border-bottom: 1px solid #ddd;
    padding: 20px;

    h1 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
      margin-bottom: 30px;
    }
  }

  section {
    padding: 24px 0;
    line-height: 30px;
    font-size: 14px;
    color: #666;
  }

  footer {
    text-align: right;
    padding: 60px 0px 20px;
  }
}
</style>